function n(n,o){const r=n;for(const t in o)o.hasOwnProperty(t)&&(r[t]=o[t]);return r}export{n as a};
