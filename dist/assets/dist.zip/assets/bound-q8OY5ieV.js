function t(t,a,i){let n=t;return void 0!==a&&(n=Math.max(t,a)),void 0!==i&&(n=Math.min(n,i)),n}export{t as b};
